#       **** START FROM HERE NEW *****
import requests
import json
BASE_URL='http://127.0.0.1:8000/'
ENDPOINT='api/'
def get_resource(id=None):
    data={}
    if id is not None:
        data={
        'id':id
        }
    resp=requests.get(BASE_URL+ENDPOINT,data=json.dumps(data))
    print(resp.json())
    print(resp.status_code)
def create_resource():
    new_emp={
     'eno': 1100,
    'ename': 'jugnu',
    'esal': 11000,
    'eaddr': 'Mau',
    }
    r=requests.post(BASE_URL+ENDPOINT,data=json.dumps(new_emp))
    print(r.json())
    print(r.status_code)
def update_resource(id):
    new_data={
    'id':id,
     'eno': 1400,
    'ename': 'Tom',
    'esal': 14000,
    'eaddr': 'America',
    }
    r=requests.put(BASE_URL+ENDPOINT,data=json.dumps(new_data))
    print(r.json())
    print(r.status_code)
def delete_resource(id):
    data={
     'id':id,
    }
    r=requests.delete(BASE_URL+ENDPOINT,data=json.dumps(data))
    print(r.json())
    print(r.status_code)
update_resource(14)