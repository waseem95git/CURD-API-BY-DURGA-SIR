from django import forms
from .models import Employee

#salry validation here
class EmployeeForm(forms.ModelForm):
    def clean_esal(self):
        inputsal=self.cleaned_data['esal']
        if inputsal < 5000:
            raise forms.ValidationError("salry should be greater tan 5000")
        return inputsal
    #its taking filed from form
    class Meta:
        model=Employee
        fields='__all__'